import sys
import math
import hpelm
import numpy as np
import torch
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier
from sklearn.feature_selection import mutual_info_classif
from sklearn.metrics import accuracy_score, f1_score, recall_score
from sklearn.model_selection import cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from torch import optim, nn
import torchvision
from torch.utils.data import DataLoader
import pandas as pd
from pokemon0 import Pokemon
from torchvision.models import resnet18
import os
import pickle
from torchvision import transforms, models
from    PIL import Image
import random
import torch
import torch.nn as nn
import torchvision.models as models
from torch.utils.data import DataLoader, SubsetRandomSampler
import torch
import torchvision.models as models
import torch.nn as nn

def evalute(model, loader):
    model.eval()

    correct = 0
    total = len(loader.dataset)
    total_val =0
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        with torch.no_grad():
            logits = model(x)
            pred = logits.argmax(dim=1)
        total_val += y.size(0)
        correct += torch.eq(pred, y).sum().float().item()

    return correct / total

def get_evaluate_acc_pred(model, loader):
    model.eval()

    correct = 0
    total = len(loader.dataset)
    total_val = 0
    predictions = []  

    for x, y in loader:
        x, y = x.to(device), y.to(device)
        with torch.no_grad():
            logits = model(x)
            pred = logits
            predictions.extend(pred.cpu().numpy())  
         
    return predictions
def get_evaluate_acc_pred0(model, loader):
    global device
    model.eval()

    correct = 0
    total = 0  
    predictions = []  # 存储所有的预测结果

    for x, y in loader:
        x, y = x.to(device), y.to(device)
        with torch.no_grad():
            logits = model(x)
            # print(logits.shape)
            pred = logits.argmax(dim=1)  # 预测类别
            predictions.extend(pred.cpu().numpy())  # 存储预测结果

        # 累计样本数
        total += y.size(0)
        # 统计正确预测的数量
        correct += (pred == y).sum().item()

    # 确保 total 不为 0
    if total == 0:
        raise ValueError("数据加载器没有提供任何样本，请检查数据加载器的配置。")

    accuracy = correct / total
    return accuracy, predictions


def getevaluteY(model, loader):
    pre_Y = []
    Y = []
    model.eval()

    correct = 0
    total = len(loader.dataset)
    
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        with torch.no_grad():
            logits = model(x)
            pred = logits.argmax(dim=1)
            # 将预测的Y和实际的Y追加到列表中
            pre_Y.extend(pred.cpu().numpy())
            Y.extend(y.cpu().numpy())
        correct += torch.eq(pred, y).sum().float().item()

    return pre_Y, Y


class ResNet18(nn.Module):
    def __init__(self):
        super().__init__()
        self.base = torchvision.models.resnet18(pretrained = True)
        
        for param in list(self.base.parameters())[:-15]:
            param.requires_grad = False
            
        self.block = nn.Sequential(
            
                nn.Linear(512, 128),
                
                nn.ReLU(inplace=True),
                nn.Dropout(),
                nn.Linear(128, 4)
        )
        self.base.classifier = nn.Sequential()
        self.base.fc = nn.Sequential()
        
        
    def forward(self, x):
        x = self.base(x)
        x = self.block(x)
        return x

class Densenet169(nn.Module):
    def __init__(self):
        super().__init__()
        self.base = torchvision.models.densenet169(pretrained=True)
        
        for param in list(self.base.parameters())[:-15]:
            param.requires_grad = False
            
        self.block = nn.Sequential(
                nn.Linear(1664, 128),
                
                nn.ReLU(inplace=True),
                nn.Dropout(),
                nn.Linear(128, 4)
                
        )
        self.base.classifier = nn.Sequential()
        self.base.fc = nn.Sequential()
        
        
    def forward(self, x):
        x = self.base(x)
        x = self.block(x)
        return x

class ConvNeXtModel(nn.Module):
    def __init__(self, num_classes=4):
        super().__init__()
        self.base = models.convnext_base(pretrained=True)  
        for param in list(self.base.parameters())[:-15]:
            param.requires_grad = False
            
        
        self.base.classifier[2] = nn.Sequential(
            nn.Flatten(), 
            nn.Linear(self.base.classifier[2].in_features, 128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, num_classes)
        )
    
    def forward(self, x):
        x = self.base(x)
        return x

def set_seed(seed):
    random.seed(seed)                       # 设置Python的随机种子
    np.random.seed(seed)                    # 设置NumPy的随机种子
    torch.manual_seed(seed)                 # 设置PyTorch的CPU随机种子
    torch.cuda.manual_seed(seed)            # 设置当前GPU的随机种子（如果使用GPU）
    torch.cuda.manual_seed_all(seed)        # 设置所有GPU的随机种子（如果使用多个GPU）
    torch.backends.cudnn.deterministic = True  # 确保每次卷积操作结果一致
    torch.backends.cudnn.benchmark = False

def l1_regularization(model, lambda_l1):
    l1_loss = 0.0
    for param in model.parameters():
        l1_loss += torch.sum(torch.abs(param))
    return lambda_l1 * l1_loss

class Flatten(nn.Module):

    def __init__(self):
        super(Flatten, self).__init__()

    def forward(self, x):
        shape = torch.prod(torch.tensor(x.shape[1:])).item()
        return x.view(-1, shape)
def generativeModel():
    global device, x_train, y_train
    
    batchsz =64
    lr = 1e-3
    epochs =20
    num_cuda_devices = torch.cuda.device_count()
    print(f"当前系统上有 {num_cuda_devices} 个可用的CUDA设备。")

    desired_device_id = 0  
    if desired_device_id < num_cuda_devices:
        torch.cuda.set_device(desired_device_id)
        print(f"已将CUDA设备切换到设备ID为 {desired_device_id} 的设备。")
    else:
        print(f"指定的设备ID {desired_device_id} 超出可用的CUDA设备数量。")
    device = torch.device('cuda:0')
    parent_dir = os.path.dirname(os.getcwd())
    
    script_path = os.path.abspath(__file__)
    
    cwd_dir = os.path.dirname(script_path)

    model_name = ["densenet169_model", "resnet18_model","ConvNeXtModel"]
    for index  in range(0,3):                    
        
        val_acc_Trial = np.zeros((5, epochs))
        train_acc_Trial = np.zeros((5, epochs))
        val_loss_Trial = np.zeros((5, epochs))
        train_loss_Trial = np.zeros((5, epochs))
        test_acc_list=np.zeros((5, 1))
        for ii in range(0, 50):  
            
            if model_name[index]=="densenet169_model":
                model=Densenet169().to(device)
            elif  model_name[index]=="resnet18_model":                
                model= ResNet18().to(device)
            elif model_name[index]=="ConvNeXtModel":
                model=ConvNeXtModel().to(device)
            else:
                pass


            filemame = f"images{0}.csv"

            if model_name[index] == "inception_model":                
                train_db = Pokemon(cwd_dir + '/data', filemame, 299, mode='train')
                val_db = Pokemon(cwd_dir + '/data', filemame, 299, mode='val')
                test_db = Pokemon(cwd_dir + '/data', filemame, 299, mode='test')
            else:
                train_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='train')
                val_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='val')
                test_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='test')
                       

            # Create indices and random sampler
            indices = np.arange(len(train_db))
            indices1 = np.arange(len(val_db))
            indices2 = np.arange(len(test_db))
            # Use SubsetRandomSampler with a random seed
            sampler = SubsetRandomSampler(indices )
            sampler1 = SubsetRandomSampler(indices1)
            sampler2 = SubsetRandomSampler(indices2)

            train_loader = DataLoader(train_db, batch_size=batchsz, sampler=sampler)
            val_loader = DataLoader(val_db, batch_size=batchsz, shuffle=False)
            test_loader = DataLoader(test_db, batch_size=batchsz, shuffle=False)

            optimizer = optim.Adam(model.parameters(), lr=lr )
            criteon = nn.CrossEntropyLoss()

            best_acc, best_epoch = 0, 0
            global_step = 0
            
            for epoch in range(epochs):
                correct_train = 0  
                total_train = 0  
                train_loss = 0  

                for step, (x, y) in enumerate(train_loader):
                
                    x, y = x.to(device), y.to(device)

                    model.train()
                    logits = model(x,)

                    if model_name[index] == 'inception_model':
                        loss = criteon(logits.logits, y)
                    else:
                        loss = criteon(logits, y)

                    optimizer.zero_grad()
                    loss.backward()
                    optimizer.step()

                    train_loss += loss.item()
                    if model_name[index] == 'inception_model':
                        _, preds = torch.max(logits.logits, 1)  
                    else:
                        _, preds = torch.max(logits, 1)  
                    correct_train += (preds == y).sum().item()
                    total_train += y.size(0)  

                    global_step += 1
                train_acc = correct_train / total_train
                avg_train_loss = train_loss / len(train_loader)
                model.eval()
                val_loss = 0
                correct_val = 0
                total_val = 0

                with torch.no_grad():
                    for val_x, val_y in val_loader:
                        val_x, val_y = val_x.to(device), val_y.to(device)

                        logits = model(val_x)

                        loss = criteon(logits, val_y)

                        
                        val_loss += loss.item()
                        
                        _, val_preds = torch.max(logits, 1)
                        correct_val += (val_preds == val_y).sum().item()
                        total_val += val_y.size(0)

                
                avg_val_loss = val_loss / len(val_loader)
                val_acc = correct_val / total_val

                
                val_acc_Trial[ii, epoch] = val_acc
                train_acc_Trial[ii, epoch] = train_acc
                val_loss_Trial[ii, epoch] = avg_val_loss
                train_loss_Trial[ii, epoch] = avg_train_loss

                if epoch % 1 == 0:

                    
                    if val_acc > best_acc:
                        best_epoch = epoch
                        best_acc = val_acc
                        dirp = cwd_dir
                        if os.path.exists(os.path.join(dirp,model_name[index],str(epochs),"50dim")) == False:
                            os.makedirs(os.path.join(dirp,model_name[index],str(epochs),"50dim"))
                        torch.save(model.state_dict(), f'{dirp}/{model_name[index]}/{str(epochs)}/50dim/best{ii}.mdl')
                
                print("epoch:", {epoch}, ":best_acc", {best_acc})
                
                print(f"Epoch [{epoch}/{epochs}] - "
                      f"Train Loss: {avg_train_loss:.4f}, Train Acc: {train_acc:.4f}, "
                      f"Val Loss: {avg_val_loss:.4f}, Val Acc: {val_acc:.4f}") 
            
            
            print('best acc:', best_acc, 'best epoch:', best_epoch)

           
                
                
               


from collections import defaultdict

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from scipy.stats import cauchy
from copy import deepcopy
from sklearn.cluster import KMeans

def default_dict_factory():
    return defaultdict(dict)

  
DimSize = 3
curFEs=0
DuckPopSize = 6
DuckPop = np.zeros((DuckPopSize, DimSize))
FitDuck = np.zeros(DuckPopSize)
BestDuck = np.zeros(DimSize)
FitBestDuck = 0

FishPopSize = 4
FishPop = np.zeros((FishPopSize, DimSize))
FitFish = np.zeros(FishPopSize)
BestFish = np.zeros(DimSize)
FitBestFish = 0

Prey = np.zeros(DimSize)

CurrentBest = np.zeros(DimSize)
FitCurrentBest = 0

TotalPopSize = DuckPopSize + FishPopSize

LB = [-100] * DimSize  # the maximum value of the variable range
UB = [100] * DimSize  # the minimum value of the variable range
TrialRuns = 1  # the number of independent runs
MaxFEs = 100 * DimSize  # the maximum number of fitness evaluations


Fun_num = 1  # the serial number of benchmark function
curIter = 0  # the current number of generations
MaxIter = math.ceil(MaxFEs / TotalPopSize)
elms=[]


def sigmoid(a):
    return 1 / (1 + np.exp(-a))


def Initialization(func):
    global DuckPop, FitDuck, FishPop, FitFish, BestDuck, BestFish, Prey, CurrentBest, FitCurrentBest, FitBestFish, FitBestDuck, CurrentBest, FitCurrentBest,curFEs
    DuckPop = np.zeros((DuckPopSize, DimSize))
    FitDuck = np.zeros(DuckPopSize)
    BestDuck = np.zeros(DimSize)
    FishPop = np.zeros((FishPopSize, DimSize))
    FitFish = np.zeros(FishPopSize)
    BestFish = np.zeros(DimSize)
    Prey = np.zeros(DimSize)
    CurrentBest = np.zeros(DimSize)
    FitCurrentBest = 0
    # randomly generate individuals
    for i in range(DuckPopSize):
        for j in range(DimSize):
            DuckPop[i][j] = LB[j] + (UB[j] - LB[j]) * np.random.rand()
            # calculate the fitness of the i-th individual
        FitDuck[i],t = func(DuckPop[i])
    for i in range(FishPopSize):
        for j in range(DimSize):
            FishPop[i][j] = LB[j] + (UB[j] - LB[j]) * np.random.rand()
            # calculate the fitness of the i-th individual
        FitFish[i],t = func(FishPop[i])
        curFEs=curFEs+1
    BestDuck = DuckPop[np.argmin(FitDuck)]
    FitBestDuck = np.min(FitDuck)

    BestFish = FishPop[np.argmin(FitFish)]
    FitBestFish = np.min(FitFish)
    if FitBestFish > FitBestDuck:
        CurrentBest = np.copy(BestDuck)
        FitCurrentBest = FitBestDuck
    else:
        CurrentBest = np.copy(BestFish)
        FitCurrentBest = FitBestFish


def Check(indi):
    global LB, UB, DimSize
    for j in range(DimSize):
        if indi[j] > UB[j] or indi[j] < LB[j]:
            indi[j] = np.random.uniform(LB[j], UB[j])
    return indi


def DGTCIA(func):
    global DuckPop, FitDuck, BestDuck, FitBestDuck, FishPop, FitFish, BestFish, FitBestFish, Prey, CurrentBest, FitCurrentBest,curFEs
    # find the best duck and fish
    BestDuck = DuckPop[np.argmin(FitDuck)]
    FitBestDuck = np.min(FitDuck)
    BestFish = FishPop[np.argmin(FitFish)]
    FitBestFish = np.min(FitFish)
    Off = np.zeros(DimSize)
    idx_duck = np.argmin(FitDuck)
    idx_fish = np.argmin(FitFish)

    A = (1 - curIter / MaxIter)
    for i in range(DuckPopSize):
        if i == idx_duck:
            target = []
            for j in range(DimSize):
                if np.random.rand() < np.random.normal(0.01, 0.01):
                    target.append(j)
            F = np.random.normal(0.5, 0.3)
            candi = list(range(0, DuckPopSize))
            r1, r2 = np.random.choice(candi, 2, replace=False)
            for j in range(DimSize):
                if j in target:
                    Off[j] = BestDuck[j]
                else:
                    if np.random.rand() < 0.05:
                        r = np.random.randint(0, DuckPopSize)
                        Off[j] = BestDuck[j] + F * (DuckPop[r1][j] - DuckPop[r][j])
                    else:
                        Off[j] = BestDuck[j] + F * (DuckPop[r1][j] - DuckPop[r2][j])
        else:
            idx = np.random.randint(0, FishPopSize)
            RandFit = FitFish[idx]
            diversity = np.mean(np.std(DuckPop, axis=0))
            if FitDuck[i] < RandFit:
                Off = DuckPop[i] + np.random.random() * (CurrentBest - DuckPop[i]) * np.sin(2 * np.pi * np.random.random()) * A * diversity
            else:

                for j in range(DimSize):
                    if np.random.random() < 0.5:
                        Off[j] = DuckPop[i][j] + np.random.normal() * A * diversity
                    else:
                        Off[j] = FishPop[idx][j] + np.random.normal() * A * diversity

        Off = Check(Off)
        FitOff,t = func(Off)
        curFEs=curFEs+1
        if FitOff < FitDuck[i]:
            DuckPop[i] = np.copy(Off)
            FitDuck[i] = FitOff
            if FitOff < FitBestDuck:
                BestDuck = np.copy(Off)
                FitBestDuck = FitOff
                if FitOff < FitCurrentBest:
                    CurrentBest = np.copy(Off)
                    FitCurrentBest = FitOff
    for i in range(FishPopSize):
        if i == idx_fish:
            target = []
            for j in range(DimSize):
                if np.random.rand() < np.random.normal(0.01, 0.01):
                    target.append(j)
            F = np.random.normal(0.5, 0.3)
            candi = list(range(0, FishPopSize))
            r1, r2 = np.random.choice(candi, 2, replace=False)
            for j in range(DimSize):
                if j in target:
                    Off[j] = BestFish[j]
                else:
                    if np.random.rand() < 0.05:
                        r = np.random.randint(0, FishPopSize)
                        Off[j] = BestFish[j] + F * (FishPop[r1][j] - FishPop[r][j])
                    else:
                        Off[j] = BestFish[j] + F * (FishPop[r1][j] - FishPop[r2][j])
        else:
            Off = BestFish - np.random.uniform(-0.5, 0.5) * (BestDuck - FishPop[i]) + np.random.uniform(-0.5, 0.5) * (DuckPop[np.random.randint(0, DuckPopSize)] - FishPop[i])

        Off = Check(Off)
        FitOff,t = func(Off)
        curFEs=curFEs+1
        if FitOff < FitFish[i]:
            FishPop[i] = np.copy(Off)
            FitFish[i] = FitOff
            if FitOff < FitBestFish:
                BestFish = np.copy(Off)
                FitBestFish = FitOff
                if FitOff < FitCurrentBest:
                    CurrentBest = np.copy(Off)
                    FitCurrentBest = FitOff

parent_dir = os.path.dirname(os.getcwd())
script_path = os.path.abspath(__file__)
cwd_dir = os.path.dirname(script_path)
device = torch.device('cuda:0')

model1=Densenet169().to(device)
model2= ResNet18().to(device)
model3=ConvNeXtModel().to(device)
epochs=20

val_loader=[]
p1= np.array([])
p2=np.array([])
p3=np.array([])
def main():
    import numpy as np
    global x_train, y_train, x_val, y_val, device,elms,model1,model2,model3,val_loader
    lr = 1e-3
    batchsz = 64

    parent_dir = os.path.dirname(os.getcwd())
    script_path = os.path.abspath(__file__)
    cwd_dir = os.path.dirname(script_path)
    
    result = defaultdict(default_dict_factory)
    
    model_name = [ "ConvNeXtModel"]

    epochs=20 
    for index  in range(len(model_name)): 
        
        All_Trial_Best = []
        elm_acc = []
        model_acc=[]

        All_test_lable = []
        All_val_lable = []

        All_model_test_lable = []
        All_model_val_lable = []
        tag=0
        for ii in range(0, 30):
            val_loader=[]
            p1= np.array([])
            p2=np.array([])
            p3=np.array([])
            
            filemame = f"images{0}.csv"
            model=ConvNeXtModel().to(device)
            

            if model_name[index] == "inception_model":                
                train_db = Pokemon(cwd_dir + '/data', filemame, 299, mode='train')
                val_db = Pokemon(cwd_dir + '/data', filemame, 299, mode='val')
                test_db = Pokemon(cwd_dir + '/data', filemame, 299, mode='test')
            else:
                train_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='train')
                val_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='val')
                test_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='test')
        

            
            indices = np.arange(len(train_db))
            indices1 = np.arange(len(val_db))
            indices2 = np.arange(len(test_db))
            sampler = SubsetRandomSampler(indices)
            train_loader = DataLoader(train_db, batch_size=batchsz,  sampler=sampler)
            val_loader = DataLoader(val_db, batch_size=batchsz, shuffle=False)
            test_loader = DataLoader(test_db, batch_size=batchsz, shuffle=False)
             
            
            model.load_state_dict(torch.load(f'{cwd_dir}/{model_name[index]}/{str(epochs)}/50dim/best{ii}.mdl'))
            
            model1.load_state_dict(torch.load(f'{cwd_dir}/densenet169_model/{str(epochs)}/50dim/best{ii}.mdl'))
            model2.load_state_dict(torch.load(f'{cwd_dir}/resnet18_model/{str(epochs)}/50dim/best{ii}.mdl'))
            model3.load_state_dict(torch.load(f'{cwd_dir}/ConvNeXtModel/{str(epochs)}/50dim/best{ii}.mdl'))

            # 存储生成的特征的路径
            file_path = os.path.join(cwd_dir, f'data/x_train{ii}_{model_name[index]}_50dim.pkl')
            file_path1 = os.path.join(cwd_dir, f'data/y_train{ii}_{model_name[index]}_50dim.pkl')
            file_path2 = os.path.join(cwd_dir, f'data/x_val{ii}_{model_name[index]}_50dim.pkl')
            file_path3 = os.path.join(cwd_dir, f'data/y_val{ii}_{model_name[index]}_50dim.pkl')
            file_path4 = os.path.join(cwd_dir, f'data/test{ii}_{model_name[index]}_50dim.pkl')
            file_path5 = os.path.join(cwd_dir, f'data/test_y{ii}_{model_name[index]}_50dim.pkl')

            # 获取训练，验证数据和测试数据
            train, train_y = get_features(model, train_loader, file_path, file_path1,model_name[index])
            val, val_y = get_features(model, val_loader, file_path2, file_path3,model_name[index])
            test, test_y = get_features(model, test_loader, file_path4, file_path5,model_name[index])

            x_train = train
            y_train = train_y
            x_val, y_val = val, val_y
            test, test_y = test, test_y
            
            from keras.utils import to_categorical
            y_train = to_categorical(y_train, 4)
            y_test = to_categorical(test_y, 4)
            y_val = to_categorical(val_y, 4)

            # Calculate total dimensions: weights + biases
            dimensions = 3            
            lb = np.ones(dimensions)*0
            ub = np.ones(dimensions)*1
            
            global curFEs, curFEs, TrialRuns, DuckPop, FitDuck, DimSize,LB,UB,elms,CurrentBest,FitCurrentBest
            DimSize = dimensions
            LB =lb
            UB =ub
            import sys
            sys.stdout = sys.__stdout__
            
            All_Trial_Best = []
            MAX = 0
            for i in range(TrialRuns):
                BestList = []
                curFEs = 0
                Initialization(softvote)
                BestList.append(min(FitDuck))
                while curFEs < MaxFEs:
                    DGTCIA(softvote)
                    BestList.append(FitCurrentBest)

                    _,elms=softvote(CurrentBest)
                    print("bestfit=", FitCurrentBest)

                MAX = max(len(BestList), MAX)
                All_Trial_Best.append(BestList)
            for i in range(len(All_Trial_Best)):
                for j in range(len(All_Trial_Best[i]), MAX):
                    All_Trial_Best[i].append(All_Trial_Best[i][-1])
            
            val_acc,val_y_pred =getvote(elms,val_loader,model1,model2,model3,y_val)            
            acc ,y_pred  =getvote(elms,test_loader,model1,model2,model3,y_test)           
            elm_acc.append( acc)

            All_test_lable.append(y_pred)
            All_val_lable.append(val_y_pred)
            print(f"inter:test_acc={ acc}")                 
            print(f"inter:val_acc={val_acc}")

            
            model.load_state_dict(torch.load(f'{cwd_dir}/{model_name[index]}/{str(epochs)}/50dim/best{ii}.mdl'))
            val_acc,val_pred_y0 = get_evaluate_acc_pred0(model, val_loader)
            test_acc ,test_pred_y0= get_evaluate_acc_pred0(model, test_loader)
            model_acc.append(test_acc)
            All_model_test_lable.append(test_pred_y0)
            All_model_val_lable.append(val_pred_y0)
    
            
            print(f"{model_name[index]}:test_acc={test_acc}")                 
            print(f"{model_name[index]}:val_acc={val_acc}")


def getvote(X,loader,model1,model2,model3,y_val):


   
    p1 = get_evaluate_acc_pred(model1,loader)
    p2 = get_evaluate_acc_pred(model2, loader)
    p3 = get_evaluate_acc_pred(model3, loader)


    pred_prob1 = torch.tensor(p1, dtype=torch.float32)
    pred_prob2 = torch.tensor(p2, dtype=torch.float32)
    pred_prob3 = torch.tensor(p3, dtype=torch.float32)  
    
    weights = [X[0], X[1], X[2]]  

   
    weighted_prob = (
        weights[0] * pred_prob1 +
        weights[1] * pred_prob2 +
        weights[2] * pred_prob3
    ) / sum(weights)

    
    y_pred = np.argmax(weighted_prob, axis=1)
    y = np.argmax(y_val,axis=1)
    accuracy = accuracy_score(y, y_pred)
    
    return accuracy,y_pred
def softvote(X):

    global x_train, y_train, x_val, y_val, TZnum, concatenate_x_train, concatenate_y_train, tag, test, test_y,model1,model2,model3,val_loader,p1,p2,p3
    
    if len(p1) == 0:
        p1 = get_evaluate_acc_pred(model1, val_loader)
        p2 = get_evaluate_acc_pred(model2, val_loader)
        p3 = get_evaluate_acc_pred(model3, val_loader)


    pred_prob1 = torch.tensor(p1, dtype=torch.float32)
    pred_prob2 = torch.tensor(p2, dtype=torch.float32)
    pred_prob3 = torch.tensor(p3, dtype=torch.float32)  
    
    weights = [X[0], X[1], X[2]]  

    
    weighted_prob = (
        weights[0] * pred_prob1 +
        weights[1] * pred_prob2 +
        weights[2] * pred_prob3
    ) / sum(weights)

    
    y_pred = np.argmax(weighted_prob, axis=1)
    y =np.argmax(y_val, axis=1)
    accuracy = accuracy_score(y, y_pred)
    
    return -1*accuracy,X

def get_features(model, train_loader, x_path, y_path,modelname):
    global device
    if (not os.path.exists(x_path)) or (not os.path.exists(y_path)):
        
        if modelname =='ConvNeXtModel':

            model.base.classifier[2][-1]=nn.Identity()
            model0 =model
        else:

           model.block[3]=nn.Identity()
           model0 = model
        model0=model
        model0.eval()

        for step, (x, y) in enumerate(train_loader):
            x, y = x.to(device), y.to(device)
            with torch.no_grad():
                
            
                if modelname == 'inception_model':
                    logits = model0(x)
                    features = logits  
                else:
                    logits = model0(x)
                    features =logits  
                
                if step == 0:
                    result = features
                    result_y = y;
                else:
                    result = torch.cat([result, features], dim=0)
                    result_y = torch.cat([result_y, y], dim=0)
        result, result_y = result.cpu(), result_y.cpu()
        with open(x_path, 'wb') as file:
            pickle.dump(result, file)
        with open(y_path, 'wb') as file:
            pickle.dump(result_y, file)

        return result.numpy(), result_y.numpy()
    else:
        with open(x_path, 'rb') as file:
            result = pickle.load(file)
        with open(y_path, 'rb') as file:
            result_y = pickle.load(file)

        return result.numpy(), result_y.numpy()




 

if __name__ == '__main__':
    generativeModel()
    main()
